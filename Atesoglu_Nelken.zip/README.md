# Mobile Computing Assignment 1
Assignment 1 of EECS 397, due 9/14/2015 @ noon

Harry Nelken

Kaan Atesoglu

Files in the Git Ignore

- .idea/*
